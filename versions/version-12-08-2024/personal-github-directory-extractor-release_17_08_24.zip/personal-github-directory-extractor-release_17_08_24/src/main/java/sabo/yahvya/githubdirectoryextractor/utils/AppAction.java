package sabo.yahvya.githubdirectoryextractor.utils;

/**
 * @brief Lambda d'action
 */
public interface AppAction {
    /**
     * @param args arguments
     */
    public void execute(Object ...args);
}
