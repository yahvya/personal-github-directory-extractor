package sabo.yahvya.githubdirectoryextractor.views.utils;

import sabo.yahvya.githubdirectoryextractor.views.views.AppVue;

import java.util.Stack;

/**
 * @brief Stack des vues
 */
public class ViewsStack extends Stack<AppVue> {
}
